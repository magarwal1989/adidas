package net.enablers.dpmgr.steps.PostPet;

import com.jayway.restassured.response.Response;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.enablers.dpmgr.helpers.ApiHelper;
import net.enablers.dpmgr.model.api.PetModels.Category;
import net.enablers.dpmgr.model.api.PetModels.PetRequestModel;
import net.enablers.dpmgr.model.api.PetModels.PetResponseModel;
import net.enablers.dpmgr.model.api.PetModels.Tags;
import net.enablers.dpmgr.services.PostPetService.PostPetService;
import org.junit.Assert;

import java.util.List;

public class FirstStep {

    Category category = new Category();
    Tags[] tags = new Tags[1];
    Tags tag = new Tags();
    PostPetService postPetService = new PostPetService();
    PetRequestModel petRequestModelList;
    Response res;
    static int id = 0;

    @When("^user enter information of pet$")
    public void userEnterInformationOfPet(List<PetRequestModel> petRequestModelList) {
        category.setId(234);
        category.setName("Pet Category");
        petRequestModelList.get(0).setCategory(category);

        tag.setId(234);
        tag.setName("tag name");
        tags[0] = tag;
        petRequestModelList.get(0).setTags(tags);
        this.petRequestModelList = petRequestModelList.get(0);
    }

    @And("^post information of pet$")
    public void postInformationOfPet() {
        res = postPetService.addNewPet(petRequestModelList);
    }

    @Then("^pet is posted successfully$")
    public void petIsPostedSuccessfully() {
        Assert.assertTrue(res.getStatusCode() == 200);
    }

    @When("^user send request to get list of pet$")
    public void userSendRequestToGetListOfPet(List<String> string) {
        res = postPetService.getPetListFromStore(string.get(0));
    }

    @Then("^Verify response$")
    public void verifyResponse() {
        Assert.assertTrue(res.getStatusCode() == 200);
    }

    @And("^update information of pet$")
    public void updateInformationOfPet() {
        res = postPetService.updatePetStatus(petRequestModelList);
    }

    @Then("^pet is updated successfully and validate it$")
    public void petIsUpdatedSuccessfullyAndValidateIt() {
        PetResponseModel petResponseModel = ApiHelper.gson().fromJson(res.getBody().prettyPrint(), PetResponseModel.class);
        Assert.assertTrue(res.getStatusCode() == 200);
        Assert.assertTrue(petResponseModel.getStatus().equals("sold"));
        this.id = petResponseModel.getId();
    }

    @When("^user enter pet id that needs to be deleted$")
    public void userEnterPetIdThatNeedsToBeDeleted() {
        res = postPetService.deletePetById(String.valueOf(id));
    }

    @Then("^verify pet is deleted$")
    public void verifyPetIsDeleted() {
        Assert.assertTrue(res.getStatusCode() == 200);
    }
}
