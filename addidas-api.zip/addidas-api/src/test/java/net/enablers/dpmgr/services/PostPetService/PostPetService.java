package net.enablers.dpmgr.services.PostPetService;

import com.jayway.restassured.response.Response;
import net.enablers.dpmgr.helpers.ApiHelper;
import net.enablers.dpmgr.model.api.PetModels.PetRequestModel;

public class PostPetService extends ApiHelper {

    public Response addNewPet(PetRequestModel petRequestModel){
        return postPet().body(gson().toJson(petRequestModel)).post("/v2/pet");
    }

    public Response getPetListFromStore(String string){
        return postPet().when().log().all().get("/v2/pet/findByStatus?status="+string);
    }

    public Response updatePetStatus(PetRequestModel petRequestModel){
        return postPet().body(gson().toJson(petRequestModel)).log().all().put("/v2/pet");
    }

    public Response deletePetById(String id){
        return postPet().when().log().all().delete("/v2/pet/"+id);
    }
}
