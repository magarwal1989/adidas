package net.enablers.dpmgr.helpers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.specification.RequestSpecification;
import com.typesafe.config.Config;
import net.enablers.dpmgr.utilities.ConfigLoader;
import net.thucydides.core.pages.PageObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;


import static com.jayway.restassured.RestAssured.given;
public class ApiHelper extends PageObject {

    private static final Logger log = LoggerFactory.getLogger(ApiHelper.class);
    static Config conf = ConfigLoader.load();
    static String BrandsApiurl = conf.getString("url");

    public static Gson gson;

    //Specify all one time default Gson config
    public static Gson gson() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gson(gsonBuilder);
        return gson;
    }

    //Custom Gson config to override Default Gson  configuration
    public static Gson gson(GsonBuilder gsonBuilder) {
        gson = gsonBuilder.create();
        return gson;
    }

    protected static RequestSpecification postPet() {
        RestAssured.baseURI = URI.create(BrandsApiurl).toString();
        return given()
                .header("accept", "application/json")
                .header("Content-Type", "application/json");
    }
}

