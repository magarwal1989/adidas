package utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import org.openqa.selenium.Platform;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import org.testng.Reporter;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;


public abstract class DriverTestCase {

	enum WebBrowser 
	{ Firefox, IE, Chrome, Safari, iPhone, Android }

	public WebDriver driver;
	public PropertyReader propertyReader;
	Random rg = new Random();
	public int n = rg.nextInt(100000);
	String USERNAME;
	String AUTOMATE_KEY;


	public void setup(String filepath) throws Exception{

		propertyReader = new PropertyReader();	
		String driverType, url, os;
		driverType=propertyReader.readApplicationFile("BROWSER",filepath);
		url=propertyReader.readApplicationFile("URL",filepath);
		os = propertyReader.readApplicationFile("OS",filepath);
		USERNAME = propertyReader.readApplicationFile("CloudUsername",filepath);
		AUTOMATE_KEY = propertyReader.readApplicationFile("CloudKey",filepath);

		//Check if desired browser is Firefox
		if (WebBrowser.Firefox.toString().equalsIgnoreCase(driverType)) 
		{ 
			//FirefoxProfile firefoxProfile = new FirefoxProfile();
			//driver = new FirefoxDriver(firefoxProfile); 
			DesiredCapabilities dc=new DesiredCapabilities();
			dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,UnexpectedAlertBehaviour.ACCEPT);
			driver =new FirefoxDriver(dc);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} 		

		//Check if desired browser is Internet Explorer
		else if (WebBrowser.IE.toString().equalsIgnoreCase(driverType)) 
		{ 
			//Set property for IEDriverServer
			String path = getPath();
			File file = new File(path+"//driver//IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

			//Accept all SSL Certificates
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

			//Create driver object
			driver = new InternetExplorerDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		}

		//Check if desired browser is Chrome
		else if (WebBrowser.Chrome.toString().equalsIgnoreCase(driverType)) 
		{   
			String path = getPath();

			System.setProperty("webdriver.chrome.driver",path+"//drivers//chromedriver");
//			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
//			ChromeOptions options = new ChromeOptions();
//			options.addArguments("test-type");
//			capabilities.setCapability("chrome.binary",path+"//driver//chromedriver.exe");
//			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		
		// check if the desired browser is safari
		else if(WebBrowser.Safari.toString().equalsIgnoreCase(driverType)) {
			
			// below  are the capabilites are for browser stack
			String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
			
			DesiredCapabilities caps = new DesiredCapabilities();
			
			caps.setCapability("browser", "Safari");   // use Chrome, IE, Safari
		    caps.setCapability("browser_version", "10.1");   // use 71, 11, 10.1 respectively for Chrome, IE, Safari
		    caps.setCapability("os", "OS X");    // use "OS X" for Mac and "Windows" for windows
		    caps.setCapability("os_version", "Sierra");   //use version as "Mojave" for Mac and "10" for windows 
		    caps.setCapability("resolution", "1024x768");

		    driver = new RemoteWebDriver(new URL(URL), caps);
		}
		
			// check if the desired browser is iphone
			else if(WebBrowser.iPhone.toString().equalsIgnoreCase(driverType)) {
				
				// below  are the capabilites are for browser stack
				
				String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
				
				DesiredCapabilities caps = new DesiredCapabilities();

			    caps.setCapability("os_version", "11");
			    caps.setCapability("device", "iPhone 8 Plus");
			    caps.setCapability("real_mobile", "true");
			    caps.setCapability("browserstack.local", "false");
			    
			    driver = new RemoteWebDriver(new URL(URL), caps);
			    driver.manage().deleteCookieNamed("");
			}
		
		// check if the desired browser is Android
		else if(WebBrowser.Android.toString().equalsIgnoreCase(driverType)) {
			
			// below  are the capabilites are for browser stack
			String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
			
			DesiredCapabilities caps = new DesiredCapabilities();
			caps.setCapability("os_version", "8.1");
			caps.setCapability("device", "Samsung Galaxy Note 9");
			caps.setCapability("real_mobile", "true");
			caps.setCapability("browserstack.local", "false");

		    
		    driver = new RemoteWebDriver(new URL(URL), caps);
		}
			
		//If browser type is not matched, exit from the system
		else 
		{   
			System.out.println("No browser was found exiting from the system.");
			System.exit(0);		
		}

		//Maximize window
		if(os.equalsIgnoreCase("Mac") | os.equalsIgnoreCase("Windows"))
			driver.manage().window().maximize();

		//Delete cookies
		driver.manage().deleteAllCookies();		
		driver.navigate().to(url);

		//Handling IE certificate
		if (WebBrowser.IE.toString().equals(driverType)) 
		{ 
			driver.get("javascript:document.getElementById('overridelink').click();");
		}
		ReporterClass.d = driver;
	}	

	@BeforeSuite
	public void startReporter() {
		ReporterClass.startReporter();
	}

	@AfterTest
	public void afterMainMethod() {		

		driver.quit();
		ExecutionLog.Log("\r\n" + 
				"*****Execution End*****\r\n" + 
				"");
		ReporterClass.log("Browser successfully closed.");
	}
	
	@AfterSuite
	public void closeReporter() {
		ReporterClass.endReporter();
	}

	public WebDriver getWebDriver(){
		return driver;
	}
	
	public int getRandomNumber(){
		return n;
	}


	//Get absolute path
	public String getPath()
	{
		String path ="";		
		File file = new File("");
		String absolutePathOfFirstFile = file.getAbsolutePath();
		path = absolutePathOfFirstFile.replaceAll("\\\\+", "/");		
		return path;
	}

}
