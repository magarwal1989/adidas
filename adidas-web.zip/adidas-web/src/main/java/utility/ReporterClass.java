package utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ReporterClass {
	
	private static ExtentReports extent;
    private static ExtentTest test;
    private static ExtentHtmlReporter htmlReporter;
    private static String path = System.getProperty("user.dir");
    private static String reportPath = path+ "//test-output//extent-report.html";
    public static WebDriver d;
    public static PropertyReader propertyReader;
    
	public static void startReporter() {
		propertyReader = new PropertyReader();	
		htmlReporter = new ExtentHtmlReporter(reportPath);
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("OS", propertyReader.readApplicationFile("OS","//src//main//resources//config//application.properties"));
        extent.setSystemInfo("Browser", propertyReader.readApplicationFile("BROWSER","//src//main//resources//config//application.properties"));
        extent.setSystemInfo("Environment", propertyReader.readApplicationFile("Environment","//src//main//resources//config//application.properties"));
        
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("AutomationTesting.in Demo Report");
        htmlReporter.config().setReportName("My Own Report");
        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.DARK);
	}

	public static void createTest(String testcasename) {
		test = extent.createTest(testcasename);
	}
	
	//this method will mark test case as pass
    public static void pass(String testcasename, String testcasedesc) throws IOException
    {
        test.pass(testcasedesc, MediaEntityBuilder.createScreenCaptureFromPath(Screenshot(testcasename)).build());
    }

    //this method will mark test case as fail
    public static void fail(String testcasename, String testcasedesc) throws IOException
    {
        
    	test.fail(testcasedesc, MediaEntityBuilder.createScreenCaptureFromPath(Screenshot(testcasename)).build());
    }
    
    //this method will mark test case as fail
    public static void skip(String testcasename, String testcasedesc) throws IOException
    {
        
    	test.skip(testcasedesc, MediaEntityBuilder.createScreenCaptureFromPath(Screenshot(testcasename)).build());
    }
	
    public static void log(String msg) {
    	test.log(Status.INFO, msg);
    }
    
    public static void endReporter() {
    	extent.flush();
    }
    
	public static ExtentReports getInstance() {
		return extent;
	}
	
	//Creating file name
	public  static String getFileName(String file)
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();		 
		String fileName = file+dateFormat.format(cal.getTime());
		return fileName;
	}
		
	public static String Screenshot(String fileName) 
	{
		String path = "";
		try 
		{
			path = System.getProperty("user.dir");
			String screenshotName = getFileName(fileName);
			path = path+"//Screenshots//" + screenshotName + ".jpg";
			FileOutputStream out = new FileOutputStream(path);
			out.write(((TakesScreenshot) d).getScreenshotAs(OutputType.BYTES));
			out.close();
		}
		catch (Exception e) 
		{ 
			
		}
		return path;

	}
	
	public static void main(String[] args) throws IOException {
		ReporterClass.startReporter();
		ReporterClass.createTest("first test case");
		ReporterClass.fail("tc_name", "tc_desc");
		ReporterClass.endReporter();
	}
}
