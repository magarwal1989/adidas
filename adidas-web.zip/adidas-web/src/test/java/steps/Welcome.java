package steps;

import java.io.IOException;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;
import pages.WelcomePages;
import utility.DriverTestCase;
import utility.ExecutionLog;
import utility.ReporterClass;

public class Welcome extends DriverTestCase{

	WelcomePages wel;
	@Given("^user launch the browser and open application url$")
	public void init() throws Throwable {
		setup("//src//main//resources//config//application.properties");
		ReporterClass.startReporter();
		ReporterClass.createTest("Checkout process");
		ExecutionLog.Log("browser launched.");
		wel = new WelcomePages(getWebDriver());
	}
	
	@Then("^Close browser$")
	public void verifyHomePageElements() throws IOException {
		System.out.println("printing here somethihg.");
		ReporterClass.fail("tc_name", "tc_desc");
		ReporterClass.endReporter();
	}

	@Then("^verify product categories$")
	public void verifyProductCategories() throws Throwable {
		Assert.assertTrue(wel.verifyPhoneCategory());
		Assert.assertTrue(wel.verifyLaptopCategory());
		Assert.assertTrue(wel.verifyMonitorCategory());
	}

	@And("^click on category \"([^\"]*)\"$")
	public void clickOnCategory(String arg0) throws Throwable {
		wel.clickOnCatogory();
	}

	@And("^click on product \"([^\"]*)\"$")
	public void clickOnProduct(String arg0) throws Throwable {
		wel.clickOnProduct(arg0);
	}

	@And("^click on add to cart button for product$")
	public void clickOnAddToCartButtonForProduct() throws Throwable {
		wel.addToCartButton();
	}

	@And("^accept the pop up$")
	public void acceptThePopUp() {
		getWebDriver().switchTo().alert().accept();
	}

	@And("^click on cart menu$")
	public void clickOnCartMenu() {
		wel.clickOnCartMenu();
	}

	@And("^Delete a product \"([^\"]*)\"$")
	public void deleteAProduct(String arg0) throws Throwable {
		wel.deleteProduct(arg0);
	}

	@And("^click on Place order button$")
	public void clickOnPlaceOrderButton() {
		wel.placeOrderButton();
	}

	@And("^fill all the information in form and click on purchase order button$")
	public void fillAllTheInformationInForm() {
		wel.fillUserInfo();
	}

	@Then("^Capture and log purchase Id and Amount$")
	public void captureAndLogPurchaseIdAndAmount() {
		wel.captureLogs();
	}

	@Then("^Assert purchase amount equals expected$")
	public void assertPurchaseAmountEqualsExpected() {
		Assert.assertTrue(WelcomePages.logs.contains(WelcomePages.amount));
	}
}
