package locators;

public class LocatorsFile {

	public final static String homeButtonLink = "(//a[contains(@href, 'index.html')])[last()]";
	public final static String cartLink = "//a[contains(@href, 'cart.html')]";
	public final static String phoneLink = "//a[contains(text(), 'Phones')]";
	public final static String laptopLink = "//a[contains(text(), 'Laptops')]";
	public final static String monitorLink = "//a[contains(text(), 'Monitors')]";
	public final static String productLink = "//a[contains(text(), '@override')]";
	public final static String addToCartButton = "//a[contains(text(), 'Add to cart')]";
	public final static String deleteProduct = "//td[contains(text(), '@override')]/..//a[contains(text(), 'Delete')]";
	public final static String placeOrderButton = "//button[contains(text(), 'Place Order')]";
	public final static String name = "//input[@id='name']";
	public final static String country = "//input[@id='country']";
	public final static String city = "//input[@id='city']";
	public final static String card = "//input[@id='card']";
	public final static String month = "//input[@id='month']";
	public final static String year = "//input[@id='year']";
	public final static String purchaseButton = "//button[contains(text(), 'Purchase')]";
	public final static String thankYou = "//*[contains(text(), 'Thank you for your purchase!')]";
	public final static String content = "//*[contains(text(), 'Thank you for your purchase!')]/following-sibling::*";
	public final static String okButton = "//button[contains(text(), 'OK')]";
	public final static String price = "//a[contains(text(), '@override')]/../following-sibling::*";
	public final static String amount = "//*[@id='totalp']";
}
