package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.google.gson.stream.JsonReader;

import locators.LocatorsFile;
import utility.DriverPage;
import utility.ExecutionLog;
import utility.PropertyReader;

public class WelcomePages extends DriverPage{

	private LocatorsFile locatorFile;
	private PropertyReader propertyReader;	
	public static String amount, logs;

	public WelcomePages(WebDriver webdriver) {
		super(webdriver);
		locatorFile = new LocatorsFile();
		propertyReader=new PropertyReader();
	}

	public boolean verifyPhoneCategory(){
		return isElementPresent(locatorFile.phoneLink);
	}

	public boolean verifyLaptopCategory(){
		return isElementPresent(locatorFile.laptopLink);
	}

	public boolean verifyMonitorCategory(){
		return isElementPresent(locatorFile.monitorLink);
	}

	public void clickOnCatogory(){
		clickOn(locatorFile.laptopLink);
	}

	public void clickOnProduct(String str){
		clickOn(locatorFile.productLink.replaceAll("@override", str));
	}

	public void addToCartButton(){
		clickOn(locatorFile.addToCartButton);
	}

	public void clickOnCartMenu(){
		clickOn(locatorFile.cartLink);
		amount = getText(locatorFile.amount);
	}

	public void deleteProduct(String arg){
		clickOn(locatorFile.deleteProduct.replaceAll("@override", arg));
	}

	public void placeOrderButton(){
		clickOn(locatorFile.placeOrderButton);
	}

	public void fillUserInfo(){
		sendKeys(locatorFile.name, "test name");
		sendKeys(locatorFile.country, "India");
		sendKeys(locatorFile.city, "Noida");
		sendKeys(locatorFile.card, "8767876543212345");
		sendKeys(locatorFile.month, "12");
		sendKeys(locatorFile.year, "2020");
		clickOn(locatorFile.purchaseButton);
	}

	public void captureLogs(){
		logs = getText(locatorFile.content);
		 System.out.println(logs);
		clickOn(locatorFile.okButton);
	}

}
